<?php
echo '<nav class="topnav" id="myTopnav">
    <a href="index.php" class="active">Home</a>
</nav>';
?>
